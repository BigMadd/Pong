// Probablemente borro esto en algún momento pero por ahora lo dejo
package logica;

public class Constantes {
	public static int ALTURA_VENTANA;
}
